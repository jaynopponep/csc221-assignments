package com.example.quizprojectfinal;

public class QALibrary {

    private static String questionsList[][] = {
            {"Which empire was ruled by both Julius Caesar and Augustus?",
            "The Magna Carta was signed in what year?",
            "What triggered the start of World War I?",
            "Who was the first female Prime Minister of Great Britain?",
            "The Renaissance was a period of great cultural and artistic change that began in which country?"},
            {"What is the chemical symbol for gold?",
            "Who proposed the theory of relativity?",
            "Which element is needed for photosynthesis to occur?",
            "What is the most abundant gas in the Earth's atmosphere?",
            "The human body is primarily composed of which molecule?"},
            {"Which of the following animals is a marsupial?",
            "What is the primary diet of a panda?",
            "The blue whale is what type of animal?",
            "What is the only bird known to fly backwards?",
            "Which animal has the longest lifespan?"}
    };

    private static String answerList[][][] = {
            {{"The Ottoman Empire", "The British Empire", "The Roman Empire", "The Mongol Empire"},
            {"1066", "1215", "1415", "1776"},
            {"The invasion of Poland", "The assassination of Archduke Franz Ferdinand", "The fall of the Berlin Wall", "The bombing of Pearl Harbor"},
            {"Queen Elizabeth I", "Margaret Thatcher", "Indira Gandhi", "Angela Merkel"},
            {"France", "Germany", "Italy", "England"}},

            {{"Au", "Ag", "Fe", "Go"},
            {"Isaac Newton", "Albert Einstein", "Niels Bohr", "Galileo Galilei"},
            {"Nitrogen", "Hydrogen", "Carbon Dioxide", "Oxygen"},
            {"Oxygen", "Hydrogen", "Carbon Dioxide", "Nitrogen"},
            {"DNA", "Protein", "Water", "Calcium carbonate"}},

            {{"Tiger", "Kangaroo", "Dolphin", "Bat"},
            {"Fish", "Insects", "Bamboo", "Small mammals"},
            {"Fish", "Amphibian", "Reptile", "Mammal"},
            {"Hummingbird", "Eagle", "Albatross", "Ostrich"},
            {"African Elephant", "Galapagos Tortoise", "Great White Shark", "Bowhead Whale"}}
    };


    private static String solutionList[][] = {
            {"The Roman Empire", "1215", "The assassination of Archduke Franz Ferdinand", "Margaret Thatcher", "Italy"},
            {"Au", "Isaac Newton", "Carbon Dioxide", "Nitrogen", "Water"},
            {"Kangaroo", "Bamboo", "Mammal", "Hummingbird", "Bowhead Whale"}
    };

    public static String getQuestions(int a, int b){
        String question = questionsList[b][a];
        return question;
    }

    public static String getAnswerOne(int a, int b){
        String answerOne = answerList[b][a][0];
        return answerOne;
    }
    public static String getAnswerTwo(int a, int b){
        String answerTwo = answerList[b][a][1];
        return answerTwo;
    }
    public static String getAnswerThree(int a, int b){
        String answerThree = answerList[b][a][2];
        return answerThree;
    }
    public static String getAnswerFour(int a, int b){
        String answerFour = answerList[b][a][3];
        return answerFour;
    }
    public static String getSolution(int a, int b){
        String solution = solutionList[b][a];
        return solution;
    }

    public static int getQuizSize(int a) {
        return questionsList[a].length;
    }

}
