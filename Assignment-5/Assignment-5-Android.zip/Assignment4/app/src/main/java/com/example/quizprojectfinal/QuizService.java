package com.example.quizprojectfinal;

import com.example.quizprojectfinal.model.Answers;
import com.example.quizprojectfinal.model.Questions;
import com.example.quizprojectfinal.model.Quiz;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface QuizService {
    @FormUrlEncoded
    @GET("quizzes/all")
    Call<List<Quiz>> getAllQuizzes();

    @POST("quizzes/quiz")
    Call<Quiz> postQuiz(@Body Quiz quiz);

    @DELETE("quizzes/clear")
    Call<Void> deleteQuiz(@Path("id") int id);

    @GET("quizzes/{quiz_id}/questions")
    Call<List<Questions>> getQuestionsByQuizId(@Path("quiz_id") int quizId);

    @GET("questions/{question_id}/answers")
    Call<List<Answers>> getAnswersByQuestionId(@Path("question_id") int questionId);

}
