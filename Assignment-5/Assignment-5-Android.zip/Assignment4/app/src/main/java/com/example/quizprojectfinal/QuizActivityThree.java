package com.example.quizprojectfinal;

import static com.example.quizprojectfinal.QALibrary.getQuizSize;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class QuizActivityThree extends AppCompatActivity {
    private TextView questionView, scoreNum;
    private Button buttonOne, buttonTwo, buttonThree, buttonFour;
    private int score = 0;
    private String answer;
    private int questionNumber = 0; // First question = 10
    private QuizService service;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.quiz_activity_layout);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://192.168.50.235:8080/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        service = retrofit.create(QuizService.class);
        questionView = (TextView)findViewById(R.id.question);
        scoreNum = (TextView)findViewById(R.id.scoreNum);
        buttonOne = (Button)findViewById(R.id.choiceOne);
        buttonTwo = (Button)findViewById(R.id.choiceTwo);
        buttonThree = (Button)findViewById(R.id.choiceThree);
        buttonFour = (Button)findViewById(R.id.choiceFour);
        TextView wrongAnswer = findViewById(R.id.wrongAnswer);
        updateQuestion();

        buttonOne.setOnClickListener(view -> { // On click button logic
            if (buttonOne.getText() == answer){ // What happens when we get the right answer
                score += 1;
                updateScore(score);
                updateQuestion();
                wrongAnswer.setVisibility(View.GONE);
            } else {
                wrongAnswer.setVisibility(View.VISIBLE);
                score -= 1;
            }
        });

        buttonTwo.setOnClickListener(view -> { // On click button logic
            if (buttonTwo.getText() == answer){ // What happens when we get the right answer
                score += 1;
                updateScore(score);
                updateQuestion();
                wrongAnswer.setVisibility(View.GONE);
            } else {
                wrongAnswer.setVisibility(View.VISIBLE);
                score -= 1;

            }
        });

        buttonThree.setOnClickListener(view -> { // On click button logic
            if (buttonThree.getText() == answer){ // What happens when we get the right answer
                score += 1;
                updateScore(score);
                updateQuestion();
                wrongAnswer.setVisibility(View.GONE);
            } else {
                wrongAnswer.setVisibility(View.VISIBLE);
                score -= 1;
            }
        });

        buttonFour.setOnClickListener(view -> { // On click button logic
            if (buttonFour.getText() == answer){ // What happens when we get the right answer
                score += 1;
                updateScore(score);
                updateQuestion();
                wrongAnswer.setVisibility(View.GONE);
            } else {
                wrongAnswer.setVisibility(View.VISIBLE);
                score -= 1;
            }
        });

    }
    private void updateQuestion(){
        int finalQuestionIndex = getQuizSize(2);
        if (questionNumber < finalQuestionIndex) {
            questionView.setText(com.example.quizprojectfinal.QALibrary.getQuestions(questionNumber, 2));
            buttonOne.setText(com.example.quizprojectfinal.QALibrary.getAnswerOne(questionNumber, 2));
            buttonTwo.setText(com.example.quizprojectfinal.QALibrary.getAnswerTwo(questionNumber, 2));
            buttonThree.setText(com.example.quizprojectfinal.QALibrary.getAnswerThree(questionNumber, 2));
            buttonFour.setText(com.example.quizprojectfinal.QALibrary.getAnswerFour(questionNumber, 2));
            answer = com.example.quizprojectfinal.QALibrary.getSolution(questionNumber, 2);
            questionNumber++;
        } else {
            Intent intent = new Intent(this, FinalScoreActivity.class);
            intent.putExtra("finalScore", score);
            intent.putExtra("totalQuestions", finalQuestionIndex);
            startActivity(intent);
        }
    }
    @SuppressLint("SetTextI18n")
    private void updateScore(int newScore) {
        scoreNum.setText(""+(newScore));
    }
}
