package com.example.quizprojectfinal;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class FinalScoreActivity extends AppCompatActivity {
    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.final_score_layout);
        TextView finalScoreView = (TextView) findViewById(R.id.finalScore);
        TextView scoreTextView = (TextView) findViewById(R.id.scoreText);
        int finalScore = getIntent().getIntExtra("finalScore", 0);
        int totalQuestions = getIntent().getIntExtra("totalQuestions", 1);

        double percentage = ((double) finalScore / totalQuestions) * 100;
        finalScoreView.setText("You scored: " + (finalScore)+"/"+(totalQuestions)+
                "\nThat's a " + percentage + "% accuracy! Click below to try another quiz.");

        Button newQuizButton = findViewById(R.id.newQuiz);
        newQuizButton.setOnClickListener(v -> {
            openNewQuiz(); {
            }
        });
    }
    public void openNewQuiz(){
        Intent intent = new Intent(this, MenuActivity.class);
        startActivity(intent);
    }
}
