package com.example.csc221test;

import static com.example.csc221test.QALibrary.getQuizSize;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class QuizActivityTwo extends AppCompatActivity {
    private TextView questionView, scoreNum;
    private Button buttonOne, buttonTwo, buttonThree, buttonFour;
    private int score = 0;
    private String answer;
    private int questionNumber = 0; // First question = 5
    private QuizService service;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.quiz_activity_layout);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://192.168.50.235:8080/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        service = retrofit.create(QuizService.class);
        questionView = (TextView)findViewById(R.id.question);
        scoreNum = (TextView)findViewById(R.id.scoreNum);
        buttonOne = (Button)findViewById(R.id.choiceOne);
        buttonTwo = (Button)findViewById(R.id.choiceTwo);
        buttonThree = (Button)findViewById(R.id.choiceThree);
        buttonFour = (Button)findViewById(R.id.choiceFour);
        TextView wrongAnswer = findViewById(R.id.wrongAnswer);
        updateQuestion();

        buttonOne.setOnClickListener(view -> { // On click button logic
            if (buttonOne.getText() == answer){ // What happens when we get the right answer
                score += 1;
                updateScore(score);
                updateQuestion();
                wrongAnswer.setVisibility(View.GONE);
            } else {
                wrongAnswer.setVisibility(View.VISIBLE);
                score -= 1;
            }
        });

        buttonTwo.setOnClickListener(view -> { // On click button logic
            if (buttonTwo.getText() == answer){ // What happens when we get the right answer
                score += 1;
                updateScore(score);
                updateQuestion();
                wrongAnswer.setVisibility(View.GONE);
            } else {
                wrongAnswer.setVisibility(View.VISIBLE);
                score -= 1;
            }
        });

        buttonThree.setOnClickListener(view -> { // On click button logic
            if (buttonThree.getText() == answer){ // What happens when we get the right answer
                score += 1;
                updateScore(score);
                updateQuestion();
                wrongAnswer.setVisibility(View.GONE);
            } else {
                wrongAnswer.setVisibility(View.VISIBLE);
                score -= 1;
            }
        });

        buttonFour.setOnClickListener(view -> { // On click button logic
            if (buttonFour.getText() == answer){ // What happens when we get the right answer
                score += 1;
                updateScore(score);
                updateQuestion();
                wrongAnswer.setVisibility(View.GONE);
            } else {
                wrongAnswer.setVisibility(View.VISIBLE);
                score -= 1;
            }
        });

    }
    private void updateQuestion(){
        int finalQuestionIndex = getQuizSize(1);
        if (questionNumber < finalQuestionIndex) {
            questionView.setText(com.example.csc221test.QALibrary.getQuestions(questionNumber, 1));
            buttonOne.setText(com.example.csc221test.QALibrary.getAnswerOne(questionNumber, 1));
            buttonTwo.setText(com.example.csc221test.QALibrary.getAnswerTwo(questionNumber, 1));
            buttonThree.setText(com.example.csc221test.QALibrary.getAnswerThree(questionNumber, 1));
            buttonFour.setText(com.example.csc221test.QALibrary.getAnswerFour(questionNumber, 1));
            answer = com.example.csc221test.QALibrary.getSolution(questionNumber, 1);
            questionNumber++;
        } else {
            Intent intent = new Intent(this, FinalScoreActivity.class);
            intent.putExtra("finalScore", score);
            intent.putExtra("totalQuestions", finalQuestionIndex);
            startActivity(intent);
        }
    }
    @SuppressLint("SetTextI18n")
    private void updateScore(int newScore) {
        scoreNum.setText(""+(newScore));
    }
}
