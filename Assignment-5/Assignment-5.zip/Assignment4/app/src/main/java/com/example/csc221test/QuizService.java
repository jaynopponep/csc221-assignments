package com.example.csc221test;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.POST;
public interface QuizService {
    /*
    @FormUrlEncoded
    @POST("user/login")
    Call<Boolean> login(@Field("username") String username, @Field("password"));
    Above code would be if function in backend Service has RequestParam instead of RequestBody.
    RequestBody is below

    @POST("user/logout")
    Call<Boolean> logout(@Body User user)
    */
}
