package com.example.csc221test;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_activity_layout);
        Button quizOneButton = findViewById(R.id.quizOne);
        Button quizTwoButton = findViewById(R.id.quizTwo);
        Button quizThreeButton = findViewById(R.id.quizThree);

        quizOneButton.setOnClickListener(v -> {
            openQuizActivityOne(); {
            }
        });

        quizTwoButton.setOnClickListener(v -> {
            openQuizActivityTwo(); {
            }
        });

        quizThreeButton.setOnClickListener(v -> {
            openQuizActivityThree(); {
            }
        });
    }

    public void openQuizActivityOne(){
        Intent intent = new Intent(this, QuizActivityOne.class);
        startActivity(intent);
    }

    public void openQuizActivityTwo(){
        Intent intent = new Intent(this, QuizActivityTwo.class);
        startActivity(intent);
    }
    public void openQuizActivityThree(){
        Intent intent = new Intent(this, QuizActivityThree.class);
        startActivity(intent);
    }

}
