package com.example.quizproject_final;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizprojectFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
