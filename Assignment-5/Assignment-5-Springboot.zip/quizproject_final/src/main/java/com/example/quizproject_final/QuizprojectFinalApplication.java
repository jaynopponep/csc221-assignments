package com.example.quizproject_final;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuizprojectFinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuizprojectFinalApplication.class, args);
	}

}
